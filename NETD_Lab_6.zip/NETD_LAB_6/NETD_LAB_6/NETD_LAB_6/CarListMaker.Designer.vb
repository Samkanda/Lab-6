﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCarListMaker
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lbMake = New System.Windows.Forms.Label()
        Me.lbModel = New System.Windows.Forms.Label()
        Me.lbYear = New System.Windows.Forms.Label()
        Me.lbPrice = New System.Windows.Forms.Label()
        Me.lbNew = New System.Windows.Forms.Label()
        Me.tbModel = New System.Windows.Forms.TextBox()
        Me.tbPrice = New System.Windows.Forms.TextBox()
        Me.chkNew = New System.Windows.Forms.CheckBox()
        Me.cmbMake = New System.Windows.Forms.ComboBox()
        Me.cmbYear = New System.Windows.Forms.ComboBox()
        Me.btnEnter = New System.Windows.Forms.Button()
        Me.lvwCarDetails = New System.Windows.Forms.ListView()
        Me.colNew = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colID = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colMake = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colYear = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colPrice = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColModel = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.btnClose = New System.Windows.Forms.Button()
        Me.lbResult = New System.Windows.Forms.Label()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.SuspendLayout()
        '
        'lbMake
        '
        Me.lbMake.Location = New System.Drawing.Point(43, 34)
        Me.lbMake.Name = "lbMake"
        Me.lbMake.Size = New System.Drawing.Size(34, 13)
        Me.lbMake.TabIndex = 0
        Me.lbMake.Text = "&Make"
        Me.lbMake.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lbModel
        '
        Me.lbModel.Location = New System.Drawing.Point(43, 79)
        Me.lbModel.Name = "lbModel"
        Me.lbModel.Size = New System.Drawing.Size(36, 13)
        Me.lbModel.TabIndex = 1
        Me.lbModel.Text = "M&odel"
        Me.lbModel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lbYear
        '
        Me.lbYear.Location = New System.Drawing.Point(43, 115)
        Me.lbYear.Name = "lbYear"
        Me.lbYear.Size = New System.Drawing.Size(29, 13)
        Me.lbYear.TabIndex = 2
        Me.lbYear.Text = "&Year"
        Me.lbYear.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lbPrice
        '
        Me.lbPrice.Location = New System.Drawing.Point(43, 152)
        Me.lbPrice.Name = "lbPrice"
        Me.lbPrice.Size = New System.Drawing.Size(31, 13)
        Me.lbPrice.TabIndex = 3
        Me.lbPrice.Text = "&Price"
        Me.lbPrice.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lbNew
        '
        Me.lbNew.Location = New System.Drawing.Point(43, 184)
        Me.lbNew.Name = "lbNew"
        Me.lbNew.Size = New System.Drawing.Size(29, 13)
        Me.lbNew.TabIndex = 4
        Me.lbNew.Text = "&New"
        Me.lbNew.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'tbModel
        '
        Me.tbModel.Location = New System.Drawing.Point(120, 76)
        Me.tbModel.Name = "tbModel"
        Me.tbModel.Size = New System.Drawing.Size(100, 20)
        Me.tbModel.TabIndex = 6
        Me.ToolTip1.SetToolTip(Me.tbModel, "Textbox of Type of model of the car")
        '
        'tbPrice
        '
        Me.tbPrice.Location = New System.Drawing.Point(120, 145)
        Me.tbPrice.Name = "tbPrice"
        Me.tbPrice.Size = New System.Drawing.Size(100, 20)
        Me.tbPrice.TabIndex = 8
        Me.ToolTip1.SetToolTip(Me.tbPrice, "Price of the car")
        '
        'chkNew
        '
        Me.chkNew.AutoSize = True
        Me.chkNew.Location = New System.Drawing.Point(120, 179)
        Me.chkNew.Name = "chkNew"
        Me.chkNew.Size = New System.Drawing.Size(15, 14)
        Me.chkNew.TabIndex = 9
        Me.ToolTip1.SetToolTip(Me.chkNew, "Check box to indiciate if car is new or used")
        Me.chkNew.UseVisualStyleBackColor = True
        '
        'cmbMake
        '
        Me.cmbMake.FormattingEnabled = True
        Me.cmbMake.Location = New System.Drawing.Point(120, 34)
        Me.cmbMake.Name = "cmbMake"
        Me.cmbMake.Size = New System.Drawing.Size(121, 21)
        Me.cmbMake.TabIndex = 5
        Me.ToolTip1.SetToolTip(Me.cmbMake, "Combo box of Make of car")
        '
        'cmbYear
        '
        Me.cmbYear.FormattingEnabled = True
        Me.cmbYear.Location = New System.Drawing.Point(120, 112)
        Me.cmbYear.Name = "cmbYear"
        Me.cmbYear.Size = New System.Drawing.Size(121, 21)
        Me.cmbYear.TabIndex = 7
        Me.ToolTip1.SetToolTip(Me.cmbYear, "Combo Box of Year car was manufactured")
        '
        'btnEnter
        '
        Me.btnEnter.Location = New System.Drawing.Point(46, 415)
        Me.btnEnter.Name = "btnEnter"
        Me.btnEnter.Size = New System.Drawing.Size(75, 23)
        Me.btnEnter.TabIndex = 12
        Me.btnEnter.Text = "&Enter"
        Me.btnEnter.UseVisualStyleBackColor = True
        '
        'lvwCarDetails
        '
        Me.lvwCarDetails.CheckBoxes = True
        Me.lvwCarDetails.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.colNew, Me.colID, Me.colMake, Me.colYear, Me.colPrice, Me.ColModel})
        Me.lvwCarDetails.FullRowSelect = True
        Me.lvwCarDetails.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable
        Me.lvwCarDetails.HideSelection = False
        Me.lvwCarDetails.Location = New System.Drawing.Point(46, 228)
        Me.lvwCarDetails.MultiSelect = False
        Me.lvwCarDetails.Name = "lvwCarDetails"
        Me.lvwCarDetails.Size = New System.Drawing.Size(353, 97)
        Me.lvwCarDetails.TabIndex = 10
        Me.ToolTip1.SetToolTip(Me.lvwCarDetails, "Listview window that displays the collection of cars")
        Me.lvwCarDetails.UseCompatibleStateImageBehavior = False
        Me.lvwCarDetails.View = System.Windows.Forms.View.Details
        '
        'colNew
        '
        Me.colNew.Text = "New"
        '
        'colID
        '
        Me.colID.Text = "ID"
        '
        'colMake
        '
        Me.colMake.Text = "Make"
        '
        'colYear
        '
        Me.colYear.Text = "Year"
        '
        'colPrice
        '
        Me.colPrice.Text = "Price"
        '
        'ColModel
        '
        Me.ColModel.Text = "Model"
        '
        'btnClose
        '
        Me.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnClose.Location = New System.Drawing.Point(166, 412)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(75, 23)
        Me.btnClose.TabIndex = 13
        Me.btnClose.Text = "&Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'lbResult
        '
        Me.lbResult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbResult.Location = New System.Drawing.Point(46, 328)
        Me.lbResult.Name = "lbResult"
        Me.lbResult.Size = New System.Drawing.Size(353, 60)
        Me.lbResult.TabIndex = 11
        Me.ToolTip1.SetToolTip(Me.lbResult, "Error Output box ")
        '
        'btnReset
        '
        Me.btnReset.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnReset.Location = New System.Drawing.Point(285, 412)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(75, 23)
        Me.btnReset.TabIndex = 14
        Me.btnReset.Text = "&Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'frmCarListMaker
        '
        Me.AcceptButton = Me.btnEnter
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnClose
        Me.ClientSize = New System.Drawing.Size(428, 450)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.lbResult)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.lvwCarDetails)
        Me.Controls.Add(Me.btnEnter)
        Me.Controls.Add(Me.cmbYear)
        Me.Controls.Add(Me.cmbMake)
        Me.Controls.Add(Me.chkNew)
        Me.Controls.Add(Me.tbPrice)
        Me.Controls.Add(Me.tbModel)
        Me.Controls.Add(Me.lbNew)
        Me.Controls.Add(Me.lbPrice)
        Me.Controls.Add(Me.lbYear)
        Me.Controls.Add(Me.lbModel)
        Me.Controls.Add(Me.lbMake)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmCarListMaker"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Car List Maker"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lbMake As Label
    Friend WithEvents lbModel As Label
    Friend WithEvents lbYear As Label
    Friend WithEvents lbPrice As Label
    Friend WithEvents lbNew As Label
    Friend WithEvents tbModel As TextBox
    Friend WithEvents tbPrice As TextBox
    Friend WithEvents chkNew As CheckBox
    Friend WithEvents cmbMake As ComboBox
    Friend WithEvents cmbYear As ComboBox
    Friend WithEvents btnEnter As Button
    Friend WithEvents lvwCarDetails As ListView
    Friend WithEvents colNew As ColumnHeader
    Friend WithEvents colID As ColumnHeader
    Friend WithEvents colMake As ColumnHeader
    Friend WithEvents colYear As ColumnHeader
    Friend WithEvents colPrice As ColumnHeader
    Friend WithEvents btnClose As Button
    Friend WithEvents lbResult As Label
    Friend WithEvents ColModel As ColumnHeader
    Friend WithEvents btnReset As Button
    Friend WithEvents ToolTip1 As ToolTip
End Class
