﻿Option Strict On
Public Class frmMultiTextEditor
#Region "Declarations"
    Dim childCount As Double
    Dim formText As Double
#End Region

    Private Sub mnuWindowsTextEditor_Click(sender As Object, e As EventArgs) Handles mnuWindowsTextEditor.Click

        childCount += 1

        Dim myTextEditor = New frmTextEditor()
        formText = childCount
        myTextEditor.Text = "Text Editor " + formText.ToString


        myTextEditor.MdiParent = Me
        myTextEditor.Show()

    End Sub


    Private Sub mnuWindowsOpenCarList_Click(sender As Object, e As EventArgs) Handles mnuWindowsOpenCarList.Click
        childCount += 1

        Dim myCarList = New frmCarListMaker()
        formText = childCount
        myCarList.Text = "Car List " + formText.ToString
        myCarList.MdiParent = Me
        myCarList.Show()
    End Sub

#Region "File Events"
    Private Sub mnuFileSave_Click(sender As Object, e As EventArgs) Handles mnuFileSave.Click

        If TypeOf (ActiveMdiChild) Is frmTextEditor Then

            CType(ActiveMdiChild, frmTextEditor).FileSave()
        Else
            MessageBox.Show("This is not a text editor")
        End If
    End Sub

    Private Sub mnuFileSaveAs_Click(sender As Object, e As EventArgs) Handles mnuFileSaveAs.Click
        If TypeOf (ActiveMdiChild) Is frmTextEditor Then

            CType(ActiveMdiChild, frmTextEditor).FileSaveAs()
        Else
            MessageBox.Show("This is not a text editor")
        End If
    End Sub

    Private Sub mnuFileNew_Click(sender As Object, e As EventArgs) Handles mnuFileNew.Click
        If TypeOf (ActiveMdiChild) Is frmTextEditor Then

            CType(ActiveMdiChild, frmTextEditor).FileNew()
        Else
            MessageBox.Show("This is not a text editor")
        End If
    End Sub

    Private Sub mnuFileOpen_Click(sender As Object, e As EventArgs) Handles mnuFileOpen.Click
        If TypeOf (ActiveMdiChild) Is frmTextEditor Then

            CType(ActiveMdiChild, frmTextEditor).FileOpen()
        End If
    End Sub

    Private Sub mnuFileExit_Click(sender As Object, e As EventArgs) Handles mnuFileExit.Click
        Me.Close()
    End Sub

    Private Sub mnuFileClose_Click(sender As Object, e As EventArgs) Handles mnuFileClose.Click

        If MdiChildren.Count > 0 Then
            ActiveMdiChild.Close()
        Else
            Me.Close()
        End If

    End Sub
#End Region

#Region "Edit Events"
    Private Sub mnuEditCut_Click(sender As Object, e As EventArgs) Handles mnuEditCut.Click
        If TypeOf (ActiveMdiChild) Is frmTextEditor Then

            CType(ActiveMdiChild, frmTextEditor).EditCut()

        Else
            MessageBox.Show("This is not a text editor")
        End If
    End Sub

    Private Sub mnuEditCopy_Click(sender As Object, e As EventArgs) Handles mnuEditCopy.Click
        If TypeOf (ActiveMdiChild) Is frmTextEditor Then

            CType(ActiveMdiChild, frmTextEditor).EditCopy()

        Else
            MessageBox.Show("This is not a text editor")
        End If
    End Sub

    Private Sub mnuEditPaste_Click(sender As Object, e As EventArgs) Handles mnuEditPaste.Click
        If TypeOf (ActiveMdiChild) Is frmTextEditor Then

            CType(ActiveMdiChild, frmTextEditor).EditPaste()

        Else
            MessageBox.Show("This is not a text editor")
        End If
    End Sub
#End Region

#Region "About"
    Private Sub mnuHelpAbout_Click(sender As Object, e As EventArgs) Handles mnuHelpAbout.Click
        If TypeOf (ActiveMdiChild) Is frmTextEditor Then

            CType(ActiveMdiChild, frmTextEditor).HelpAbout()

        Else
            MessageBox.Show("This is not a text editor")
        End If
    End Sub


#End Region
#Region "Windows Events"
    Private Sub mnuWindowsCascade_Click(sender As Object, e As EventArgs) Handles mnuWindowsCascade.Click

        Me.LayoutMdi(MdiLayout.Cascade)
    End Sub

    Private Sub mnuWindowsTileHorizontal_Click(sender As Object, e As EventArgs) Handles mnuWindowsTileHorizontal.Click
        Me.LayoutMdi(MdiLayout.TileHorizontal)
    End Sub

    Private Sub mnuWindowsTileVertical_Click(sender As Object, e As EventArgs) Handles mnuWindowsTileVertical.Click
        Me.LayoutMdi(MdiLayout.TileVertical)
    End Sub

#End Region

#Region "Buttons"
    Private Sub ToolStripButton1_Click(sender As Object, e As EventArgs) Handles btnNew.Click
        If TypeOf (ActiveMdiChild) Is frmTextEditor Then

            CType(ActiveMdiChild, frmTextEditor).FileNew()
        Else
            MessageBox.Show("This is not a text editor")
        End If
    End Sub

    Private Sub ToolStripButton2_Click(sender As Object, e As EventArgs) Handles btnOpen.Click
        If TypeOf (ActiveMdiChild) Is frmTextEditor Then

            CType(ActiveMdiChild, frmTextEditor).FileOpen()
        Else
            MessageBox.Show("This is not a text editor")
        End If
    End Sub

    Private Sub ToolStripButton3_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If TypeOf (ActiveMdiChild) Is frmTextEditor Then

            CType(ActiveMdiChild, frmTextEditor).FileSave()
        Else
            MessageBox.Show("This is not a text editor")
        End If
    End Sub

#End Region

End Class


