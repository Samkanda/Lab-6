﻿'By: Navpreet Kanda
'Date: 2020-03-13
'Description: This represents the car class that stores certain properties regarding each car unit

Option Strict On
Public Class frmCarListMaker

#Region "Variable Declarations"
    Dim result As Decimal
    Dim selectedCar As CarClass       ' Declaration of Class
    Dim isCarSelected As Boolean = False
    Dim isAddingToListView As Boolean = False
    Dim carList As New List(Of CarClass)  ' Declaration of Collection
#End Region

    ' Validation Function
    Function isValidInput() As Boolean
        Dim returnValue As Boolean = True

        If tbModel.Text = String.Empty Then
            lbResult.Text += "Please input Model Name" & vbCrLf
            returnValue = False
        End If

        If Decimal.TryParse(tbPrice.Text, result) Then
            If tbPrice.Text.Trim.Length > 0 Then
                If Convert.ToDecimal(tbPrice.Text) >= 0 Then

                Else
                    lbResult.Text += "please input valid number" & vbCrLf
                    returnValue = False
                End If
            Else
                lbResult.Text += "please input valid number" & vbCrLf
                returnValue = False
            End If
        Else
            lbResult.Text += "Please enter a value that is Numeric" & vbCrLf
            returnValue = False
        End If

        'Validation for Make Combo Box
        If (String.IsNullOrEmpty(cmbMake.Text)) Then
            lbResult.Text += "Please Select value from Make DropDown" & vbCrLf
            returnValue = False
        End If

        'Validation for Year Combo Box
        If (String.IsNullOrEmpty(cmbYear.Text)) Then
            lbResult.Text += "Please Select Year from DropDown" & vbCrLf
            returnValue = False

        End If
        Return returnValue

    End Function

#Region "Event Handlers"
    Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click

        ' Checks if input values are valid
        If isValidInput() = True Then

            ' Passes variable to Class
            If Not isCarSelected Then
                selectedCar = New CarClass(cmbMake.Text, tbModel.Text, Convert.ToInt32(cmbYear.Text), Convert.ToDecimal(tbPrice.Text), chkNew.Checked)

                carList.Add(selectedCar)

                ' If Selected, updates list item
            ElseIf selectedCar.ID > 0 Then
                selectedCar.isNew = chkNew.Checked
                selectedCar.Make = cmbMake.Text
                selectedCar.Model = tbModel.Text
                selectedCar.Year = Convert.ToInt32(cmbYear.Text)
                selectedCar.Price = Convert.ToDecimal(tbPrice.Text)
            End If
        End If

        SetDefault()

    End Sub

    Private Sub lvwCarDetails_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lvwCarDetails.SelectedIndexChanged
        If lvwCarDetails.SelectedIndices.Count = 1 Then
            selectedCar = carList(lvwCarDetails.SelectedIndices(0))
            isCarSelected = True

            tbModel.Text = selectedCar.Model
            tbPrice.Text = Convert.ToString(selectedCar.Price)
            cmbMake.Text = selectedCar.Make
            cmbYear.Text = Convert.ToString(selectedCar.Year)
            selectedCar.isNew = chkNew.Checked
        Else
            isCarSelected = False
        End If
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Adding items to Make combo box
        cmbMake.Items.Add("Honda")
        cmbMake.Items.Add("Tesla")

        ' Generation of year items 
        Dim year As Integer = 2020
        For i As Integer = 0 To 100

            cmbYear.Items.Add(year)
            year = (year - 1)

        Next
    End Sub

    ' Presents modification of checkbox
    Private Sub lvwCarDetails_ItemCheck(sender As Object, e As ItemCheckEventArgs) Handles lvwCarDetails.ItemCheck

        If Not isAddingToListView Then

            e.NewValue = e.CurrentValue
        End If
    End Sub
#End Region

#Region "Procedures"
    Sub SetDefault()
        tbModel.Clear()
        tbPrice.Clear()
        chkNew.Checked = False
        PopulateList()
        isCarSelected = False
        tbModel.Focus()

    End Sub

    Private Sub cmbMake_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbMake.KeyPress
        e.Handled = True
    End Sub

    Private Sub cmbYear_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles cmbYear.KeyPress
        e.Handled = True
    End Sub
    Sub PopulateList()

        'Clear items from listview
        lvwCarDetails.Items.Clear()

        ' Loop that repopulates Collection
        For index As Integer = 0 To carList.Count - 1

            Dim carUnits As New ListViewItem()

            'Assinging values to Collection
            carUnits.Checked = (carList(index).isNew)
            carUnits.SubItems.Add(carList(index).ID.ToString())
            carUnits.SubItems.Add(carList(index).Make)
            carUnits.SubItems.Add(carList(index).Year.ToString())
            carUnits.SubItems.Add(carList(index).Price.ToString())
            carUnits.SubItems.Add(carList(index).Model)

            isAddingToListView = True
            lvwCarDetails.Items.Add(carUnits)

            isAddingToListView = False
        Next

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        SetDefault()


    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub
End Class

#End Region
